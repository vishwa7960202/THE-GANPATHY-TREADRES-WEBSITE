var brands=["UltraTech","Sintex","Birla White","Parryware","CERA","V-Guard","Prime Gold TMT","iSteel XLS","Astral","Prince Piping","JSW Neosteel"];
var t=document.getElementById('track'),h='';
for(var k=0;k<2;k++)brands.forEach(function(b){h+='<span>'+b+'</span>'});
t.innerHTML=h;
document.getElementById('yr').textContent=new Date().getFullYear();
var io=new IntersectionObserver(function(es){es.forEach(function(e){
 if(e.isIntersecting){e.target.classList.add('in');
  var c=e.target.querySelector('[data-n]');
  if(c&&!c.done){c.done=1;var n=+c.dataset.n,s=c.dataset.s||'+',i=0;
   var iv=setInterval(function(){i++;c.textContent=Math.round(n*i/40)+(i>=40?s:'');if(i>=40)clearInterval(iv)},35)}
  io.unobserve(e.target)}})},{threshold:.15});
document.querySelectorAll('.reveal').forEach(function(el,i){el.style.transitionDelay=(i%4)*90+'ms';io.observe(el)});

/* ====== SHOP SETTINGS – change these values anytime ====== */
var CONFIG={
 whatsapp:"919942764747",          // order messages go to this number
 freeCementBrand:"UltraTech Cement", // cement that earns free delivery
 freeCementQty:20,                 // bags needed for free delivery
 zones:[                           // delivery charge by distance (Rs). null = confirm by call
  {label:"Within 5 km",charge:250},
  {label:"5 to 10 km",charge:400},
  {label:"10 to 20 km",charge:600},
  {label:"20 to 40 km",charge:900},
  {label:"Above 40 km (charge confirmed by call)",charge:null}
 ]
};
var PRODUCTS=[
 ["UltraTech Cement","bags"],["Birla White Wall Putty","bags"],["Prime Gold TMT Steel","tons"],["iSteel XLS TMT Steel","tons"],
 ["JSW Neosteel TMT","tons"],["Parryware Sanitaryware","pcs"],["CERA Sanitaryware","pcs"],["Sintex Water Tank","pcs"],
 ["Astral Pipes and Fittings","pcs"],["Prince Piping System","pcs"],["V-Guard Electricals","pcs"],["Other (write in notes)","pcs"]
];
var items=[];
function $(i){return document.getElementById(i)}
PRODUCTS.forEach(function(p,i){$("prod").add(new Option(p[0]+" ("+p[1]+")",i))});
CONFIG.zones.forEach(function(z,i){$("zone").add(new Option(z.label+(z.charge!==null?" – Rs "+z.charge:""),i))});

function calc(){
 var cement=0;items.forEach(function(it){if(it.name===CONFIG.freeCementBrand)cement+=it.qty});
 var del=$("mode").value==="delivery",z=CONFIG.zones[$("zone").value];
 var r={free:false,charge:0,text:""};
 if(!del){r.text="Pick up from shop – no delivery charge"}
 else if(cement>=CONFIG.freeCementQty){r.free=true;r.text="FREE delivery (UltraTech cement "+cement+" bags)"}
 else if(z.charge===null){r.text="Long-distance charge will be confirmed by us"}
 else{r.charge=z.charge;r.text="Delivery charge: Rs "+z.charge;}
 r.cement=cement;return r;
}
function render(){
 var ul=$("list");ul.innerHTML="";
 items.forEach(function(it,i){
  var li=document.createElement("li");
  li.innerHTML="<span>"+it.name+" × <b>"+it.qty+"</b> "+it.unit+"</span>";
  var b=document.createElement("button");b.textContent="✕";b.setAttribute("aria-label","Remove");
  b.onclick=function(){items.splice(i,1);render()};li.appendChild(b);ul.appendChild(li);
 });
 $("delBox").style.display=$("mode").value==="delivery"?"block":"none";
 var c=calc(),h="<b>Items:</b> "+items.length+"<br>";
 h+=c.free?'<span class="free">🎉 '+c.text+"</span>":c.text;
 if($("mode").value==="delivery"&&!c.free){
  var need=CONFIG.freeCementQty-c.cement;
  h+="<br><small>Order "+CONFIG.freeCementQty+"+ "+CONFIG.freeCementBrand+" bags for free delivery"+(c.cement>0?" (add "+need+" more)":"")+".</small>";
 }
 h+="<br><small>Product prices will be confirmed by us on WhatsApp.</small>";
 $("sum").innerHTML=h;
}
$("addBtn").onclick=function(){
 var p=PRODUCTS[$("prod").value],q=parseInt($("qty").value,10);
 if(!q||q<1){$("err").textContent="Enter a valid quantity.";return}
 $("err").textContent="";
 var ex=items.filter(function(x){return x.name===p[0]})[0];
 if(ex)ex.qty+=q;else items.push({name:p[0],unit:p[1],qty:q});
 $("qty").value=1;render();
};
["mode","zone"].forEach(function(id){$(id).onchange=render});
$("sendBtn").onclick=function(){
 var n=$("cname").value.trim(),ph=$("cphone").value.trim(),del=$("mode").value==="delivery",ad=$("addr").value.trim(),nt=$("note").value.trim();
 var e="";
 if(!items.length&&!nt)e="Please add at least one item or write your requirement.";
 else if(!n)e="Please enter your name.";
 else if(!/^[6-9]\d{9}$/.test(ph))e="Enter a valid 10-digit mobile number.";
 else if(del&&!ad)e="Please enter the delivery address.";
 $("err").textContent=e;if(e)return;
 var c=calc(),m="*NEW ORDER – The Ganapathy Traders*\n\n*Customer:* "+n+"\n*Mobile:* "+ph+"\n\n*Order list:*\n";
 items.forEach(function(it,i){m+=(i+1)+". "+it.name+" – "+it.qty+" "+it.unit+"\n"});
 if(nt)m+="\n*Notes:* "+nt+"\n";
 m+="\n*Mode:* "+(del?"Delivery":"Pick up from shop")+"\n";
 if(del)m+="*Address:* "+ad+"\n*Distance:* "+CONFIG.zones[$("zone").value].label+"\n";
 m+="*Delivery:* "+c.text+"\n\nPlease confirm the price and availability. Thank you!";
 window.open("https://wa.me/"+CONFIG.whatsapp+"?text="+encodeURIComponent(m),"_blank");
};
render();